<?php

$databaseHost = 'localhost';
$databaseName = 'KedaiDuluDulu';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername,$databasePassword, $databaseName );
?>
